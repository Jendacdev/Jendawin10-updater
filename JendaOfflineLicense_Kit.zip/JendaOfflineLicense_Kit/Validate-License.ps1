Param(
  [Parameter(Mandatory=$true)][string]$License,
  [Parameter(Mandatory=$true)][string]$UserName,
  [int]$Year = 0,
  [string]$Secret = "JendaSecret2025"
)
function Test-LicenseFormat([string]$lic){
    return ($lic -match '^JU-\d{4}-[A-F0-9]{4}-[A-F0-9]{4}$')
}
function Compute-Expected([string]$User,[int]$Year,[string]$Secret){
    $Base = ($User.ToUpper() + "-" + $Year)
    $hmac = New-Object System.Security.Cryptography.HMACSHA256 ([Text.Encoding]::UTF8.GetBytes($Secret))
    $hashBytes = $hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes($Base))
    $hash = ([System.BitConverter]::ToString($hashBytes)).Replace("-","").ToUpper()
    return $hash.Substring(0,8)
}
if (-not (Test-LicenseFormat $License)){
    Write-Host "❌ Neplatný formát licence." ; exit 2
}
$parts = $License.Split('-')
$licYear = [int]$parts[1]
$tag = $parts[2] + $parts[3]
if ($Year -eq 0) { $Year = $licYear }
$expected = Compute-Expected -User $UserName -Year $Year -Secret $Secret
if ($expected.Substring(0,8) -eq $tag){
    Write-Host "✅ Licence je platná pro uživatele '$UserName' (rok $Year)."
    exit 0
} else {
    Write-Host "❌ Licence je neplatná nebo uživatel nesouhlasí."
    exit 1
}
