
# Jenda Offline License Kit

OFFLINE licence bez databáze a serveru. Klíč je vázán na **uživatelské jméno** a **rok** a je ověřitelný lokálně pomocí stejného tajného hesla (Secret).

## Formát klíče
`JU-YYYY-XXXX-YYYY` (8 hex znaků z HMAC-SHA256(UserName + "-" + Year, Secret))

## Soubory
- `Generate-License.ps1` – vygeneruje klíč
- `Validate-License.ps1` – ověří klíč
- `README.md` – návod

## Použití
### Generování
```powershell
$secret = "MojeTajnaFrase_ChangeThis!"
.\Generate-License.ps1 -UserName "Jan" -Secret $secret
.\Generate-License.ps1 -UserName "Jan" -Year 2026 -Secret $secret
```
### Ověření
```powershell
$secret = "MojeTajnaFrase_ChangeThis!"
.\Validate-License.ps1 -License "JU-2025-ABCD-1234" -UserName "Jan" -Secret $secret
```
Pokud nepředáš `-Year`, použije se rok z klíče.

## Bezpečnost
- Změň si `Secret` na dlouhý náhodný řetězec a **neveřej ho**.
- Offline systém je jednoduchý, ale méně bezpečný než serverové ověřování.
