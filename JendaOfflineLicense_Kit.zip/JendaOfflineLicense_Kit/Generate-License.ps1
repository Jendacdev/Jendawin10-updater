Param(
  [Parameter(Mandatory=$true)][string]$UserName,
  [int]$Year = (Get-Date).Year,
  [string]$Secret = "JendaSecret2025"
)
function New-LicenseKey([string]$User,[int]$Year,[string]$Secret){
    $prefix = "JU"
    $Base = ($User.ToUpper() + "-" + $Year)
    $hmac = New-Object System.Security.Cryptography.HMACSHA256 ([Text.Encoding]::UTF8.GetBytes($Secret))
    $hashBytes = $hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes($Base))
    $hash = ([System.BitConverter]::ToString($hashBytes)).Replace("-","").ToUpper()
    $part1 = $hash.Substring(0,4)
    $part2 = $hash.Substring(4,4)
    return "{0}-{1}-{2}-{3}" -f $prefix,$Year,$part1,$part2
}
$key = New-LicenseKey -User $UserName -Year $Year -Secret $Secret
Write-Host ("Licenční klíč pro '{0}': {1}" -f $UserName,$key)
