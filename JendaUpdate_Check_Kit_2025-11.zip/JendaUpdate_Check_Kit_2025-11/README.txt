
# Jenda Update – Check Kit (2025.11)

Zkontroluje, zda je Windows 10 (22H2) a klíčové komponenty aktuální.
- `manifest.json` – co kontrolujeme a minimální verze
- `JendaCheck.ps1` – spustí diagnostiku, uloží report (CSV/JSON), volitelně provede opravy (`-Fix`)

## Použití
1) Otevři PowerShell jako **správce**.
2) Povol dočasně skripty:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
3) Spusť kontrolu:
   .\JendaCheck.ps1
   nebo s automatickými opravami:
   .\JendaCheck.ps1 -Fix

Reporty najdeš v `reports\report_*.csv` a `report_*.json`.
