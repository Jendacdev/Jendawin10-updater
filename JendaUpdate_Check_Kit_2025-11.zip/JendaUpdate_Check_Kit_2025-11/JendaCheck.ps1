Param([switch]$Fix)

$ErrorActionPreference = "Stop"

function Out-Result([string]$id,[string]$name,[string]$current,[string]$required,[string]$status,[string]$note){
  [PSCustomObject]@{ Id=$id; Name=$name; Current=$current; Required=$required; Status=$status; Note=$note }
}

function Compare-Version($a,$b){
  try {
    $va = [version]($a -replace '[^\d\.]','')
    $vb = [version]($b -replace '[^\d\.]','')
    if ($va -lt $vb) { return -1 } elseif ($va -gt $vb) { return 1 } else { return 0 }
  } catch { return 0 }
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Get-Content (Join-Path $root "manifest.json") | ConvertFrom-Json
$results = @()

foreach($c in $manifest.components){
  $cur = ""
  $ok = $false
  $required = $c.minVersion

  try {
    switch ($c.detect.type) {
      'registry' {
        $val = (Get-ItemProperty -Path $c.detect.path -ErrorAction Stop).$($c.detect.value)
        $cur = "$val"
        if ($c.id -eq 'dotnet_framework' -and $c.minRelease){
          $required = $c.minRelease.ToString()
          $ok = ([int]$val -ge [int]$c.minRelease)
        } else {
          $ok = (Compare-Version $cur $c.minVersion) -ge 0
        }
      }
      'cmdlet' {
        $cur = Invoke-Expression $c.detect.command
        $ok = (Compare-Version $cur $c.minVersion) -ge 0
      }
      'command' {
        $cur = (& cmd.exe /c $c.detect.command) 2>$null
        if (-not $cur){ $cur = "" }
        $ok = (Compare-Version $cur.Trim() $c.minVersion) -ge 0
      }
      default {
        $cur = "(neznámá detekce)"
        $ok = $false
      }
    }
  } catch {
    $cur = "(nenalezeno)"
    $ok = $false
  }

  $status = if ($ok) { "OK" } else { "MISSING/OUTDATED" }
  $results += Out-Result $c.id $c.name ($cur -join ' ') ($required) $status $c.note
}

$results | Sort-Object Status, Name | Format-Table -AutoSize

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$repDir = Join-Path $root "reports"
New-Item -ItemType Directory -Path $repDir -ErrorAction SilentlyContinue | Out-Null
$csv = Join-Path $repDir ("report_"+$ts+".csv")
$json = Join-Path $repDir ("report_"+$ts+".json")
$results | Export-Csv -NoTypeInformation -Path $csv -Encoding UTF8
$results | ConvertTo-Json | Out-File -FilePath $json -Encoding UTF8

Write-Host "`nReport uložen:" $csv
Write-Host "Report (JSON):" $json

if ($Fix){
  Write-Host "`n[FIX] Pokus o instalaci/aktualizaci chybějících komponent..."
  foreach($r in $results | Where-Object {$_.Status -eq "MISSING/OUTDATED"}){
    $comp = $manifest.components | Where-Object {$_.id -eq $r.Id}
    if (-not $comp) { continue }
    if ($comp.downloadUrl){
      $ts2 = Get-Date -Format "HHmmss"
      $tmp = Join-Path $env:TEMP ("jenda_"+$comp.id+"_"+$ts2)
      New-Item $tmp -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
      $file = Join-Path $tmp ([System.IO.Path]::GetFileName(($comp.downloadUrl -split '\?')[0]))
      try{
        Write-Host "  - Stahuji $($comp.name) z $($comp.downloadUrl)"
        Invoke-WebRequest -Uri $comp.downloadUrl -OutFile $file -UseBasicParsing -TimeoutSec 1800
        if ($file -like '*.msixbundle'){
          Add-AppxPackage -Path $file -ForceApplicationShutdown
        } elseif ($file -like '*.msi'){
          Start-Process "msiexec.exe" -ArgumentList "/i `"$file`" $($comp.silentArgs)" -Wait -NoNewWindow
        } else {
          Start-Process $file -ArgumentList $comp.silentArgs -Wait -NoNewWindow
        }
        Write-Host "    -> OK"
      } catch {
        Write-Warning "    -> Selhalo: $_"
      }
    } else {
      Write-Warning "  - Pro $($comp.name) není definovaný downloadUrl (ruční instalace)."
    }
  }
  Write-Host "[FIX] Dokončeno. Spusť skript znovu pro ověření."
}
