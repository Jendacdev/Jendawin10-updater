
# Jenda Update Pack 2025.12 (Starter)
Aktualizace komponent po EOL Windows 10: Defender, Edge, .NET 4.8.1, VC++ x64/x86, PowerShell 7, WinGet + tweaky.
## Použití
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
JendaUpdate_Agent_2025.12.cmd
Logy v `updates\2025.12\logs\apply_*.log`.
