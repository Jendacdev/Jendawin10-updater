$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $root
$manifest = Get-Content (Join-Path $root "manifest.json") | ConvertFrom-Json
$logDir = Join-Path $root "logs"
New-Item -ItemType Directory $logDir -ErrorAction SilentlyContinue | Out-Null
$log = Join-Path $logDir ("apply_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".log")
function Log($m){ $m | Tee-Object -FilePath $log -Append }
Log "[INFO] Jenda Update Pack $($manifest.version) start"
foreach($c in $manifest.components){
  try{
    switch($c.type){
      "command" { Log "[RUN] $($c.command)"; & cmd.exe /c $c.command | Tee-Object -FilePath $log -Append }
      "download_install" {
        $tmp = Join-Path $env:TEMP ("jenda_" + $c.id + "_" + (Get-Date -Format "HHmmss"))
        New-Item $tmp -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
        $file = Join-Path $tmp ([System.IO.Path]::GetFileName(($c.url -split '\?')[0]))
        Log "[DL] $($c.url) -> $file"
        Invoke-WebRequest -Uri $c.url -OutFile $file -UseBasicParsing -TimeoutSec 1800
        if ($file -like '*.msixbundle'){ Log "[APPX] Add-AppxPackage $file"; Add-AppxPackage -Path $file -ForceApplicationShutdown }
        elseif ($file -like '*.msi'){ Log "[MSI] msiexec /i $file $($c.silent)"; Start-Process "msiexec.exe" -ArgumentList "/i `"$file`" $($c.silent)" -Wait -NoNewWindow }
        else { Log "[EXE] $file $($c.silent)"; Start-Process $file -ArgumentList $c.silent -Wait -NoNewWindow }
      }
    }
  } catch { Log "[ERROR] $($_.Exception.Message)" }
}
foreach($t in $manifest.tweaks){
  try{ Log "[TWEAK] $($t.name)"; Invoke-Expression $t.powershell | Out-Null } catch { Log "[WARN] Tweak selhal: $($_.Exception.Message)" }
}
Log "[DONE] Hotovo."; Write-Host "Log: $log"
